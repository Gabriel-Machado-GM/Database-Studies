# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#Comentario de uma linha só
#PRIMEIRA AULA
print("Hello\n", "\tWorld", "!")

name = " victor "

print(name.upper())
print(name.lower())
print(name.title())

#limpa as parte vazias da esquerda ou direita ou ambos
print(name.rstrip())
print(name.lstrip())
print(name.strip())

NUM_ALUNOS = 30 #Variavel constante, porem em python ela nao se mantem
#deve ser todo em caixa alta CAPS LOCK

idade_da_terra = 5_000_000_000
#podemos escrever numeros assim

print(idade_da_terra)

