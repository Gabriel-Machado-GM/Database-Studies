# -*- coding: utf-8 -*-

#AULA 2 - CRIANDO VETORES
x = 1
x = 0
x = [0, 1]

filosofos = ["Marco Aurélio", "Zenão de Cítio", "Sêneca"]
print(filosofos)

#Indice -  Seleciona o elemento de uma lista
print(filosofos[0])
#Em python, o primeiro é sempre 0
print(filosofos[1])

#a função help() permite voce obter ajuda do IDE sobre
#outra função
help(print)

#imprime na ordem inversa
print(filosofos[-1])

#sobre escreve o valor ja existente
filosofos[2] = "Guido Mantega"
print(filosofos)

#Cria-se um apêndice - adiciona-se ao final
filosofos.append("Sêneca")
print(filosofos)

#Adiciona um valor em um ponto determinado
filosofos.insert(1, "Panécio de Rodes")
print(filosofos)

#Laço de repetição
for cont in [0,1,2,3]:
    print(cont, end=' ')
#O tab na linha abaixo do FOR diz ao Python que essa linha faz
#parte do FOR
# esse end = ' ' muda a forma pela qual o print é dado

#para darmos espaço entre uma linha e outra usamos o \n
print('\n')
for cont in [0,1,2,3]:
    print(filosofos[cont])
    
#podemos usar o RANGE para podemos dizer uma sequencia de numeros
print('\n')
for cont in range(0, 10):
    print(cont, end=' ')

#podemos contar de dois em dois
print('\n')
for cont in range(0, 10, 2):
    print(cont, end=' ')

#podemos ter uma ordem inversa
print('\n')
for cont in range(100, 0, -1):
    print(cont, end=' ')    
    
print('\n')    
for cada_filosofo in filosofos:
    print(cada_filosofo)
#o vetor é criado pelo FOR, e fica com o valor de cada valor do vetor
    
#podemos ter valor tomadores de cada letra
print('\n')  
for cada_letra in filosofos[0]:
    print(cada_letra)
    
#podemos fazer um laço de repetição dentro de um laço de repetição
print('\n')  
for cada_filosofo in filosofos:
    for cada_letra in cada_filosofo:
        print(cada_letra)
    print("-----")

#deletar elemento de uma pilha
print('\n')
del filosofos[3]
print(filosofos)

#Com o pop, removemos o ultimo elemento de uma lista
# e podemos utilizar essa função
print('\n')
print(filosofos.pop())
print(filosofos)

#podemos escolher tambem qual elemento vai ser tirado
print('\n')
print(filosofos.pop(1))
print(filosofos)

#podemos remover um elemento da lista
print('\n')
filosofos.remove("Zenão de Cítio")
print(filosofos)

#a função .remove remove a primeira ocorrencia da especificação








