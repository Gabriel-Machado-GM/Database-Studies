# -*- coding: utf-8 -*-

#AULA 4
lista = ["beterraba", "acabate", "banana","uva"]
lista2 = ["jujuba", "acabate", "banana","uva"]
print(lista)
print("\n")

#MUDA A LISTA PRA SEMPRE E ORDENA
lista.sort()
print(lista)
print("\n")

#PODE MUDAR A ORDEM DA LISTA
lista.sort(reverse=True)
print(lista)
print("\n")

#PODEMOS MOSTRAR ORDENADO SEM MUDAR A LISTA 
#PARA SEMPRE QUANDO USAMOS METODOS
print(sorted(lista2))
print("\n")
print(lista2)
print("\n")

#FUNÇÃO É A Q VEM COM .FUNÇÃO
#MÉTODO VEM COMO MÉTODO()

#PODEMOS INVERTER A ORDEM DE ELEMENTOS DA LISTA
lista2.reverse()
#AQUI NÃO TEMOS ORDEM ALFABETICA AO CONTRARIO
print("\n")

#PARA SABERMOS O TAMANHO DE UMA LISTA len(obj)
print(len(lista2))
#PRECISAMOS MANDAR IMPRIMIR OU ASSOCIÁLA A UMA FUNÇÃO
#POIS TEMOS APENAS UM NÚMERO
print("\n")
numeros_pares = list(range(2,101,2))
print(numeros_pares)
print(min(numeros_pares))
print(max(numeros_pares))
print(sum(numeros_pares))
print("\n")

#USANDO LISTAS NO FOR
# ** é elevado à
quadrados = []
for num in range(1,11):
    quadrado = num ** 2
    quadrados.append(quadrado)
print(quadrados)
print("\n")

#PODEMOS PUXAR O ELEMENTO DE UMA LISTA ASSIM
print(lista[1])
print(lista[0:3])
#PYTHON SEMPRE TEM INTERVALOS FECHADOS, PRIMEIRO NUMERO
#E INTERVALOS ABERTOS, SEGUNDO NUMERO (NÃO INCLUSO)
print("\n")
#PARA PEGAR UM INTERVALO MAIOR PODEMOS DEIXAR EM BRANCO
print(lista[0:])
print(lista[:4])
print(lista[:])
#PODEMOS INVERTER A ORDEM
print(lista[-3:])
print("\n")

#PODEMOS COPIAR UMA LISTA ASSIM
lista3 = []
lista3.append(lista[:])
lista3.append(lista2[:])
print(lista3)








