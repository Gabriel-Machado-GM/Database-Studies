# -*- coding: utf-8 -*-
"""
Created on Mon May 25 15:44:11 2020

@author: solbo
"""
#PARA USAR FUNÇÕES DE FORA DO DOCUMENTO, USAMOS O IMPORT

import random as ran
import modulo_nome as nom
import modulo_resp as resp

#PARA PUXARMOS A FUNÇÃO DE UM MÓDULO, DEVEMOS DIZER O NOME DO MÓDULO ANTES DE CHAMAR A FUNÇÃO
#random.seed(1) <- DETERMINA A SEED, NAO É MAIS ALEATORIO
#print(ran.randint(1,10),ran.randint(1,10),ran.randint(1,10))

def jogo():
    nom.nome()
    resp.resp()
    
jogo()

"""
def num_magic():
    x = ran.randint(1, 10)
    return x

"""