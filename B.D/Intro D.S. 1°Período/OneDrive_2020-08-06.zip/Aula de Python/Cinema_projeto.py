# -*- coding: utf-8 -*-
"""
Created on Fri May 29 16:33:19 2020

@author: solbo
"""


A = []
B = []
C = []
D = []
E = []
Seq = []
cont1 = 0
cont2 = 0
cont3 = 0
cont4 = 0
cont5 = 0

while cont1 < 10:
    A.append(0)
    cont1 = cont1 + 1
while cont2 < 10:
    B.append(0)
    cont2 = cont2 + 1
while cont3 < 10:
    C.append(0)
    cont3 = cont3 + 1
while cont4 < 10:
    D.append(0)
    cont4 = cont4 + 1
while cont5 < 10:
    E.append(0)
    cont5 = cont5 + 1
for ss in range(10):
    Seq.append(ss)
T = [ " ", "T", "E","L", "A" ," ", ]

fil = [T,A,B,C,D,E]
fileira = ["0","1","2","3","4"]


def criar_fileira():
    cont = 0
    fileira = []
    while cont < 10:
        fileira.append(0)
        cont+= 1
    return fileira



def exibir_cinema():
    T = [ " ", "T", "E","L", "A" ," ", ]
    fil = [T,A,B,C,D,E]
    fileira = ["0","1","2","3","4"]
    for i in range(5):
            print(f"{fileira[i]} - {fil[i]}")

def exibir_fileira():
    print(Seq)
        print(f"{fil[f]}")

def cinema():
    vezes = 0
    print("\n")
    print("Bem vindo ao Cinema Pop! A próxima sessão já vai começar!")
    n_poltrona = int(input("Quantos ingressos gostaria de comprar? "))
    meias = int(input("Quantas meias? "))
    inteiras = int(input("Quantas inteiras? "))
    while meias + inteiras != n_poltrona:
        print("Opa! Esse número não parece certo! Digite novamente! ")
        meias = int(input("Quantas meias? "))
        inteiras = int(input("Quantas inteiras? "))
    preco_meia = 5
    preco_inteira = 10
    valor = preco_inteira * inteiras + preco_meia * meias
    print("\n")
    
    while vezes != n_poltrona:
        for i in range(5):
            print(f"{fileira[i]} - {fil[i]}")
            
        f = int(input("Escolha uma fileira: "))
        print("\n")
        while f != 1 and f != 2 and f != 3 and f != 4:
            print("\n")
            for i in range(5):
                print(f"{fileira[i]} - {fil[i]}")
            f = int(input("Valor inválido. Escolha uma fileira: "))
        print(Seq)
        print(f"{fil[f]}")
        a = int(input("Escolha um assento: "))
        while a != 0 and a != 1 and a != 2 and a != 3 and a != 4 and a != 5 and a != 6 and a != 7 and a != 8 and a != 9:
            print("\n")
            print(Seq)
            print(f"{fil[f]}")
            a = int(input("Valor inválido. Escolha um assento: "))
        while fil[f][a]==1:
            print("\n")
            print(Seq)
            print(f"{fil[f]}")
            a = int(input("Poltrona ocupada! Escolha um assento: "))
        print("\n")
        fil[f][a] = 1
        
        vezes = vezes + 1
    for i in range(5):
            print(f"{fileira[i]} - {fil[i]}")
    print("\n")
    print("Os lugares marcados, foram estes!") 
    print(f"À pagar: R${valor} , bom filme!")     
    
cinema()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
