# -*- coding: utf-8 -*-
"""
Created on Mon May 25 18:36:06 2020

@author: solbo
"""
import random as ran

def jogo_magic():
    nome = str(input("Bem vindo ao jogo do Número Mágico! Digite o seu nome: "))
    print("\n")
    print(f"{nome.title()}, você deve advinhar um número de 1 a 10!")
    print("Você tem 4 tentativas!")
    print("\n")
    vidas = 8
    num_magic = ran.randint(1,10)
    resposta = int(input("Digite um número: "))
    while vidas > 1:
        if resposta != num_magic:
            vidas = vidas - 1
            print(f"Ei {nome}! Você errou! Você ainda tem {vidas} chances!")
            resposta = int(input("Digite um número: "))
        else:
            print("Parabéns, você acertou!")
            return
    print("Você perdeu! Tente novamente!")
    
jogo_magic()   
    
    
    
    
    