# -*- coding: utf-8 -*-
"""
Created on Fri Jun  5 14:10:44 2020

@author: solbo

1- Menu
    : Comprar Pizza
    : Sair
2 - Escolher 5 ingredientes. P.ex. massa, queijo, etc.
    Med) O usuario escolhe apenas 1 vez cada tipo de ingrediente
        Ingredientes obrigatorios e opcionais
        Cada ingrediente tem seu preço
    Hard) Alguns Ingredientes podem ser escolhidos mais de uma vez
3 - Exibir a pizza, o custo e pedir confirmacao
    : Descartada
    : Solicitar endereço e metodo de pagamento
    
    HARD cada ingrediente tem estoque
    HARDHARD cada usuario pode comprar mais de uma pizza


"""
massa = "Massa ainda não escolhida"
queijo = []
complemento = [] 
    
def menu(massa, queijo, complemento):
    asd = 0
    print()
    print("Seja bem vindo à Pizza Pop!") 
    
    while asd == 0:
        print("___________________________________")    
        print("Você gostaria de...")  
        print("1 - Escolher a pizza")
        print("2 - Exibir compras do carrinho")
        print("3 - Terminar e pagar")
        print("4 - Sair")
        print("___________________________________")
        comando = int(input(": "))
        if comando == 1:
            asd = 1
            fazer_pizza(massa, queijo, complemento)
            asd = 0
        elif comando == 2:
            asd = 1
        elif comando == 3:
            asd = 1
        elif comando == 4:
            print()
            print("Volte sempre!")
            break
        
def fazer_pizza(massa, queijo, complemento):
   fazer = 0
   while fazer == 0:
        print("___________________________________")    
        print("Para fazer uma pizza, devemos escolher alguns ingredientes:")  
        print("1 - Escolher massa")
        print("2 - Escolher queijo")
        print("3 - Escolher complementos")
        print("4 - Exibir pizza")
        print("5 - Voltar ao menu")
        print("___________________________________")
        print()
        comando = int(input(": "))
           
        if comando == 1:
            fazer = 1
            escolher_massa(massa)
            fazer = 0
        elif comando == 2:
            fazer = 1
            escolher_queijo(queijo)
            fazer = 0
        elif comando == 3:
            fazer = 1
            print("EM TESTE")
            fazer = 0
        elif comando == 4:
            fazer = 1
            exibir_pizza(massa, queijo, complemento)
            fazer = 0
        elif comando == 5:
            break

         
        
           
        

def escolher_massa(massa):
    
    print("___________________________________")    
    print("1 - Massa fina")
    print("2 - Massa tradicional")
    print("___________________________________")
    print()
    cmassa = int(input(": "))
    while cmassa != 1 and cmassa != 2:
        print("Comando inválido! Digite 1 ou 2!")
        print("___________________________________")
        print("1 - Massa fina")
        print("2 - Massa tradicional")
        print("___________________________________")
    if cmassa == 1:
        massa = "Massa fina"
    elif cmassa == 2:
        massa = "Massa Tradicional"
    return massa


def escolher_queijo(queijo):
    
    cont_queijo = 0
    print("___________________________________")
    print("Você pode escolher até três queijos!")
    print("1 - Mozzarela")
    print("2 - Catupiry")
    print("3 - Gorgonzola")
    print("4 - Provolone")
    print("5 - Apenas os já selecionados")
    print("___________________________________")
    print()
    cqueijo = int(input(": "))
    while cont_queijo < 3:
        while cqueijo != 1 and cqueijo != 2 and cqueijo != 3 and cqueijo != 4 and cqueijo != 5:
            exibir_queijo()
        if cqueijo == 1:
            queijo.append("Mozzarela")
            cont_queijo += 1
            print("Queijos escolhidos:")
            for i in queijo:
                print(f"{i}", end = "  ")
            print()
            exibir_queijo()
            cqueijo = int(input(": "))
            
        elif cqueijo == 2:
            queijo.append("Catupiry")
            cont_queijo += 1
            print("Queijos escolhidos:")
            for i in queijo:
                print(f"{i}", end = "  ")
            print()
            exibir_queijo()
            cqueijo = int(input(": "))
        
        elif cqueijo == 3:
            queijo.append("Gorgonzola")
            cont_queijo += 1
            print("Queijos escolhidos:")
            for i in queijo:
                print(f"{i}", end = "  ")
            print()
            exibir_queijo()
            cqueijo = int(input(": "))
        
        elif cqueijo == 4:
            queijo.append("Provolone")
            cont_queijo += 1
            print("Queijos escolhidos:")
            for i in queijo:
                print(f"{i}", end = "  ")
            print()
            exibir_queijo()
            cqueijo = int(input(": "))
              
        elif cqueijo == 5:
            return queijo
            break
    return queijo
    print(" ")
            

def exibir_pizza(massa, queijo, complemento):
    print("___________________________________")
    print("INGREDIENTES")
    print(massa)
    for i in queijo:
        print(i, end = "   ")
    print()
    for i in complemento:
        print(i, end = "   ")
    print()
    print("___________________________________")

def exibir_queijo():
    print("___________________________________")
    print("Você pode escolher até três queijos!")
    print("1 - Mozzarela")
    print("2 - Catupiry")
    print("3 - Gorgonzola")
    print("4 - Provolone")
    print("5 - Apenas os já selecionados")
    print("___________________________________")
    print()
                
    
menu()
    
    
    
    
    
    
    
    
    