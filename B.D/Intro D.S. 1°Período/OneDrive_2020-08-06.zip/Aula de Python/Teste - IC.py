# -*- coding: utf-8 -*-
""" 
#QUESTÃO 1

def calculo():
    valor_compra = int(input("Digite o valor da compra: "))
    parcelas = int(input("Digite a quantidade de parcelas: "))
    taxa_juros = int(input("Digite a taxa de juros (percentual por mês): "))
    while parcelas < 1 or valor_compra <= 0 or taxa_juros < 0:
        print("Erro! Valor de parcelas, taxa de juros valor da compra inválidos! Digite novamente!")
        valor_compra = int(input("Digite o valor da compra: "))
        parcelas = int(input("Digite a quantidade de parcelas: "))
        taxa_juros = int(input("Digite a taxa de juros (percentual por mês): "))
    if parcelas == 1:
        total = (valor_compra*(1 + (taxa_juros/100))) * 0.9
        comissao = total * 0.07
        print(f"Apenas umas parcela! Você tem 10% de desconto! Total a pagar de R${total}.")
        print(f"A comissão do vendedor foi R${comissao}!")
    elif parcelas > 1:
            parc = valor_compra/parcelas
            total = 0
            for cont in range(1, parcelas+1):          
                total = total + parc * (1 + taxa_juros/100)
                print(f"Parcela {cont}: R${round(total,2)}.")  
            comissao = round(total*0.07,2)
            print(f"A comissão do vendedor foi R${comissao}!")     
                    
calculo()
"""

"""
Questão 2 (Fácil) [3.0 Pontos] - Elabore uma função que recebe N e 
retorna o fatorial de N - utilize um laço de repetição para o cálculo.
Demonstre o funcionamento da função elaborada em um programa.

def fatorial(N):
    N = int(input("Digite um número:"))
    total = 1
    for N in range(1,N+1):
        print(f"{N}", end=" ")
        total*=N   
    print(f"O fatorial do número {N}, é {total}")

numero_fatorial = fatorial("N")



Questão 3 (Fácil+) [4.0 Pontos] – Elabore uma função que recebe N e,
 caso N seja par, retorna "H = 1/1 - 2/4 + 3/9 - 4/16 + 5/25 - ..." até o 
n-ésimo elemento. Caso N seja ímpar, a função deve retornar -1.
 Demonstre o funcionamento da função elaborada em um programa.



def  num():
    N = int(input("Digite um número: "))
    if N%2 == 0:
        for i in range(1, N+1):
            if i%2 == 0:
                total = i
                total2 =(i**2)
                print(f"- {total}/{total2}", end = ' ')
            elif i == 1:
                total = i
                total2 = (i**2)
                print(f"{total}/{total2}", end = ' ')
            else:
                total = i
                total2 = (i**2)
                print(f"+ {total}/{total2}", end = ' ')
        
    else: 
        print("-1")

num()
"""
"""
#Questão Extra
def numero_perfeito():
    num = int(input("Digite um número: "))
    tot=0
    for n in range(1,num):
        if num % n == 0:
            tot +=n
    if tot == num:
        print("É perfeito -> 1")
    else:
        print("Não é perfeito -> 0")

numero_perfeito()
"""




