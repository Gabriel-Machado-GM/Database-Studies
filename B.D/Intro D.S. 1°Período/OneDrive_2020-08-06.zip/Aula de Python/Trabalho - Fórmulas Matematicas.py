# -*- coding: utf-8 -*-
"""
Created on Wed May 27 15:42:01 2020

@author: solbo
"""
import math
#PRIMEIRA FORMULA------------------------------------------------------
"""
def triangulo():
    a = int(input("Digite o valor do primeiro lado:"))
    b = int(input("Digite o valor do segundo lado:"))
    c = int(input("Digite o valor do terceiro lado:"))

    while a <= 0 or b <= 0 or c <= 0:
      print("Valores de lados inválidos! Digite-os novamente!'") 
      a = int(input("Digite o valor do primeiro lado:"))
      b = int(input("Digite o valor do segundo lado:"))
      c = int(input("Digite o valor do terceiro lado:"))
    if a + b > c and a + c > b and b + c > a:
        print("\n")
        print("O seu triângulo existe! Ele é: ")
        if a**2 == b**2 + c**2 or  a**2 + c**2 == b**2  or a**2 + b**2 == c**2:
            print("-Retângulo")
        if a ==  b or b == c or a == c:
            print("-Isóceles")
            if a==b==c : 
                print("-Equilátero")
        else:
            print("-Escaleno")
        print("\n")
        p = (a + b + c)/2
        heron = p * (p - a)* (p - b)* (p - c)
        area = heron**0.5
        print(f"A área do seu triângulo vale {round(area,2)} unidades de área.")
    else:
        print("\n")
        print("O seu triângulo não existe!")
        
triangulo()
"""

#SEGUNDA FORMULA------------------------------------------------------
"""
def quadrat():
    print("Esta função acha as raízes reais de uma função quadratica.")
    a = float(input("Digite o valor de a: "))
    b = float(input("Digite o valor de b: "))
    c = float(input("Digite o valor de c: "))
    delta = b**2 - 4 * a * c
    if delta < 0:
        print("Esta função não possui raízes reais.")
    elif delta == 0:
         x = (-b + delta**(1/2))/2*a
         print("\n")
         print(f"Sua raíz é {x} .")
    elif delta > 0  :
        print("\n")
        x1 = (-b + delta**(1/2))/2*a
        x2 = (-b - delta**(1/2))/2*a
        print(f"Suas raízes são {x1} e {x2} .")

quadrat()
"""

#TERCEIRA FORMULA------------------------------------------------------
"""
def pg():
    a1 = float(input("Digite o termo inicial: "))
    q = float(input("Defina a razão: "))
    n = int(input("Defina a quantidade de termos na progressão: "))
    for i in range(1,n+1):
       an = a1 * q**(i-1)
       print(f"{i} - {an}")
    soma = (a1*(1-q**n))/(1-q)
    print("\n")
    print(f"O valor da soma dos elementos da progressão é {soma}.")
pg()
"""

#QUARTA FORMULA------------------------------------------------------

"""
def soma_rieamann():
  # 
   # Essa função calcula a área sob a curva de eq. 1, 2 ou 3 
   # pela soma de Riemann dados os parâmetros.
    funcs = [" ","x²", "√x", "Sen(x)"]
    print("Funções: ")
    for m in range(1,4):
        print(f"{m} - {funcs[m]}")
    
    print("Opa!!! Bora calcular uma integralzinha?")
    c = int(input("Escolha uma das curvas 1, 2 ou 3: "))
    a = int(input("Entre com o limite inferior, please: "))
    b = int(input("Pra finalizar, agora o superior: "))
    print("\n")
    while b < a:
        b = int(input("Agora com o superior decente, por favor: "))
    n = 1000000
    dx = abs((b - a)/n)
    x = 0
    if c == 1:
        s = 0
        for i in range(n):
            f = x**2
            s = s + dx*abs(f)
            x = a + i*dx
            i = i + 1
        return(s, c);
    
    elif c == 2:
        s = 0
        while a < 0 or b < 0:
            a = int(input("Esta função não está definida para valores negativos. Entre um limite superior positivo: "))
            b = int(input("Pra finalizar, agora o superior: "))
        for i in range(n):
            f = x**0.5
            s = s + dx*abs(f)
            x = a + i*dx
            i = i + 1
        return(s, c);
    elif c == 3:
        s = 0
        for i in range(n):
            f = math.sin(x)
            s = s + dx*abs(f)
            x = a + i*dx
            i = i + 1
        return(s, c);
    else:
        print("Po, mano tu tá de palhaçada? Só tinha 3 opcões e errou... Aí não né?!")
        return c
s, c = soma_rieamann()

print(f"A área sob a curva {round(c, 3)} é {round(s, 3)} u.a.")
"""

#QUINTA FORMULA------------------------------------------------------
"""
def fat(n):
    '''
    Calcula n fatorial
    '''
    if n > 0:
        i = a = 1
        while i <= n:
            a *= i 
            i += 1       
        return a
    elif n == 0:
        return 1
    else:
        print("Poxa... não existe fatorial de nº negativo.")
        
        import fat
def ei():
    '''
    Essa função retorna o nº pi ou o nº de Euler

    '''
    num = input("Escolha: Pi ou e")
    n = 10**6
    x = s = 0
    if num == "pi":
        for i in range(n + 1):
            f = (1/(1 + x**2))
            x = i/n
            s += 4*f/n
            i += 1
        return s
    elif num == "e":
        i = s = 0
        for i in range(1000):
            f = 1/fat.fat(i)
            s += f
            i += 1
        return round(s, 4)
    else:
        return "tururu"

ei()
"""

#SEXTA FORMULA------------------------------------------------------
"""
def fibo():
    x = [1]
    y = int(input("Escolha um número: "))
    for i in range(1,y+1):
        if i == 1:
            x.append(i) 
        else:
                x.append(x[i-1] + x[i-2])

    for l in x:
        print(l)

fibo()
"""

#SETIMA FORMULA------------------------------------------------------
"""

'''
Uma função que, dados os números de casos acumulados para dois dias consecutivos, 
calcula uma taxa de crescimento diário e usa essa taxa para estimar o número de casos 
acumulados em uma data futura (escolhida pelo usuário).

Atenção: Como taxas de variação de número de casos variam ao longo do tempo, 
essa projeção não é nem um pouco acurada para períodos longos de tempo. A tendência é a
taxa diminuir conforme o número de casos aumenta, pois a taxa é calculada em razão
do número de casos do dia anterior e é mais fácil ter taxas grandes quando as bases são
pequenas (por exemplo, passar de 1 caso para 3 casos significaria uma taxa enorme)
Porém, para uma projeção de poucos dias, acreditamos que esse método ainda seja razoavelmente bom.
'''

def covid():
    
    print("\n Oiee! Preparado para fazer uma projeção bacana?")
    
    casos_ontem = int(input("Por favor, digite o número de casos acumulados ontem: "))
    while casos_ontem < 1:
        print("\nEi, caso negativo não existe!")
        casos_ontem = int(input("Digite o número de casos acumulados ontem: "))
    
    casos_atuais = int(input("Por favor, digite o número de casos acumulados hoje: "))
    while casos_atuais < 1:
        print("\nEi, caso negativo não existe!")
        casos_atuais = int(input("Digite o número de casos acumulados ontem: "))
    while casos_atuais > 0 and casos_atuais < casos_ontem: #casos cumulativos de hoje não podem ser menores que os de ontem
        print("\nPoxa, parça, o número de casos acumulados diminuiu?? Ce n'est pas possible!")
        casos_atuais = int(input("Digite o número de casos acumulados hoje: "))    
    
    taxa = casos_atuais/casos_ontem
    
    dias = int(input("Agora, digite a duração da projeção (em dias): "))
    while dias < 1:
        print("hmm... bora usar pelo menos um dia, tá?")
        dias = int(input("Duração da projeção (dias): "))
    
    print("\nValeu!\n")    
    print("Ta aí o que você queria:")   
    
    for ii in range(1, dias + 1):
        casos_atuais = round(casos_atuais * taxa)
        print(f"Número de casos depois de {ii} dia(s): {casos_atuais}")
    
covid()


"""

#OITAVA FORMULA------------------------------------------------------
"""
#Essa função calcula a derivada de um polinômio simples em um determinado
#valor de x

def derivar():
    print("\nOlá, amiguinho! Vamos derivar um polinômio??")
    
    while True:
        grau = int(input("Por favor, digite o maior grau desse polinômio (Só números positivos, tá bom?): "))
        if grau > 0:
            break
        
    lista_coef = []    
    
    for ii in range(grau, 0, -1):
        lista_coef.append(float(input(f"Digite o coeficiente de x**{ii}: ")))
        
    x_val = float(input("Agora, digite o valor de x no ponto desejado: "))
    
    print("\nShow de bola!")
    
    derivada = 0
    
    lista_coef.reverse()
    
    for ii in range(1, grau + 1):
        derivada += lista_coef[ii - 1] * ii * x_val**(ii-1)
    
    print(f"\nO resultado é {derivada}")
    
    return derivada

derivar()
"""

#NONA FORMULA------------------------------------------------------
"""
def pa():
    a1 = float(input("Digite o primeiro termo da PA: "))
    n = int(input("Digite a quantidade de termos na PA: "))
    r = float(input("Digite a razão da PA: "))
    for i in range(n):
        an = a1 + (i) * r
        print(f"{i+1} - {an}")

pa()
"""

#DECIMA FORMULA------------------------------------------------------
"""
def little_fermat():
    '''Essa função diz se um nº é ou não primo
    '''
    a = 2
    print("Quer saber se seu nº é primo? Então hoje é seu dia de sorte!!!")
    m = int(input("Manda o nº, please: "))
    while m == 0:
        m = int(input("Ah, esqueci de te contar, o número 0 não vale, ok?\nManda outro, por favore:  "))
    if (a**(m-1))%m == 1 or m == 2:
        return f"O nº {m} é primo!"
    else:
        return f"O nº {m} não é primo."

print(little_fermat())

"""

















