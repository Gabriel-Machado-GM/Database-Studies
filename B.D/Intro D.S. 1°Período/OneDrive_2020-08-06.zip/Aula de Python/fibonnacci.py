# -*- coding: utf-8 -*-
"""
Created on Mon May 25 16:45:50 2020

@author: solbo
"""

x = [1]
y = 15

for i in range(1,y+1):
    if i == 1:
        x.append(i) 
    else:
        x.append(x[i-1] + x[i-2])

for l in x:
    print(l)
