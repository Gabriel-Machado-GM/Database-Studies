# -*- coding: utf-8 -*-
"""
Created on Mon May 25 15:45:05 2020

@author: solbo
"""
import random as ran
def num_mag():
    x = ran.randint(1, 10)
    return x

c = num_mag()
print(c)