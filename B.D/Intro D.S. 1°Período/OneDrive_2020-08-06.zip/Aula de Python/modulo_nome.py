# -*- coding: utf-8 -*-
"""
Created on Mon May 25 16:20:21 2020

@author: solbo
"""

def nome():
    nome = str(input("Olá, este é o jogo Número Mágico. Digite seu nome: "))
    print(f"{nome}, você deve acertar o número mágico para vencer. Boa sorte!")

nome()