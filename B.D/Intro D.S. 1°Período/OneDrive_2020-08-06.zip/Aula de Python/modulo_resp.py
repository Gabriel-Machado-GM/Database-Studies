# -*- coding: utf-8 -*-
"""
Created on Mon May 25 16:28:50 2020

@author: solbo
"""
import random as ran
def resp():
    numero_magico = ran.randint(1, 10)
    resposta = int(input("Por favor, digite um número entre 1 e 10: "))
    num_resp = []
    for mm in range(1,6):
        num_resp.append(1)
    
    if len(num_resp = 5):
        ""
    
    while resposta != numero_magico:
        print("\nVocê é bobão!")
        resposta = int(input("Por favor digite um número entre 1 e 10: "))
    
    print("Você é demais!")

