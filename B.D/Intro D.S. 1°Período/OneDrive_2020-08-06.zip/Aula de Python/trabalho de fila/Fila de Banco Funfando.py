# -*- coding: utf-8 -*-

'''FILA DE BANCO
0 - Modelar a fila utilizando listas
    Med) Criar uma lista padrão e criar uma lista prioritário
    Hard) Criar uma única lista
1 - Definir a função: inserir_cliente
    A) inserir_cliente_normal
    B) inserir_cliente_prioritário
2 - Definir a função: atender_cliente
    A) atender_cliente_normal
    B) atender_cliente_prioritário
    Med) Sempre atender clientes prioritários primeiro
    Hard) avoiding starvation: a cada 4 clientes prioritários atendidos,
 você deve atender 1 cliente normal (isto é, se houver um cliente normal)
3 - Definir a função: exibir_filas
    Med) Exibindo a quantidade de clientes
    Hard) Fazer um desenho da fila
'''

def criar_fila():
    fila = []
    return fila

def menu(fila): 
    sair = 1
    while sair !=0:
         print("_____________________________________")
         print("[0] para sair ")
         print("[1] para adicionar cliente")
         print("[2] para atender próximo cliente")
         print("[3] para exbir a fila")
         print("_____________________________________")
         comando = int(input(": "))
         while comando !=0 and comando != 1 and comando !=2 and comando !=3:
             print("COMANDO INVALIDO")
             
             print("[1] para adicionar cliente")
             print("[2] para atender próximo cliente")
             print("[3] para exbir a fila")
             comando = int(input(": "))
         if comando == 0:
             break
         elif comando == 1:
             inserir_cliente(fila)
         elif comando == 2:
             atendimento(fila)
         elif comando == 3:
             exibir_fila(fila)

def inserir_cliente(fila):
    prioridade = int(input("Para cliente prioritário, digite 0. Caso contrário, digite 1: "))
    if prioridade == 0:
        fila.append(0)
    else:
        fila.append(1)

def atender_cliente_normal(fila):
    for i in range(len(fila)):
        if fila[i] == 1:
            fila.pop(i)
            return fila
            break
    
def atender_cliente_prioritario(fila):
    for i in range(len(fila)):
        if fila[i] == 0:
            fila.pop(i)
            return fila
            break
        


def exibir_fila(fila):
    for i in fila:
        print("---", end = "")
    print()
    for i in fila:
        if i ==0:
            print(" P ", end="")
        else:
            print(" C ", end="")
    print()
    for i in fila:
        print("---",end = "")
    print()  



x = 0
def atendimento(fila): 
    p = 0
    n = 0
    global x
    for i in range(len(fila)):
        if fila[i] == 0:
            p +=1
        if fila [i] ==1:
            n +=1
    if p > 0:
        for i in range(len(fila)):
            if x < 4:
                if fila[i] == 0:
                    atender_cliente_prioritario(fila)
                    x = x + 1
                    exibir_fila(fila)
                    break
            else:
                atender_cliente_normal(fila) 
                x = 0
                exibir_fila(fila)
                break
    else:
        atender_cliente_normal(fila) 
        exibir_fila(fila)

fila = criar_fila()  
menu(fila)




"""

1	for i, el in enumerate(["a","b","c"]):
2	    print(i)
3	    print(el)

"""






