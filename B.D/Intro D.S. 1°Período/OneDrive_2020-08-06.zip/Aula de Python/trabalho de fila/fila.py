# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 12:26:28 2020

@author: Daniela, Lívia, Bombarda
"""

import modulo_fila.py as md

fila = md.criar_lista()

#o primeiro argumento é a fila, e o segundo é o número de clientes 
#que você quer inserir
md.inserir_clientes(fila, 10)

print()
print("Lista antes do antendimento:")
md.exibir_fila(fila)

#o primeiro argumento é a fila, e o segundo é o número de clientes 
#que você quer atender
md.atender_clientes(fila, 6)

print()
print("Lista depois do antendimento:")
md.exibir_fila(fila)

#se lista for por exemplo [0,0,0,0,0,0,1,1,0,1]
#nao funciona