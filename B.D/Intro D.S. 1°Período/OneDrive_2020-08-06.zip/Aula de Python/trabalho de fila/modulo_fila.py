# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 11:35:02 2020

@author: Daniela, Lívia, Bombarda
"""

'''FILA DE BANCO
0 - Modelar a fila utilizando listas
    Med) Criar uma lista padrão e criar uma lista prioritário
    Hard) Criar uma única lista
1 - Definir a função: inserir_cliente
    A) inserir_cliente_normal
    B) inserir_cliente_prioritário
2 - Definir a função: atender_cliente
    A) atender_cliente_normal
    B) atender_cliente_prioritário
    Med) Sempre atender clientes prioritários primeiro
    Hard) avoiding starvation: a cada 4 clientes prioritários atendidos,
 você deve atender 1 cliente normal (isto é, se houver um cliente normal)
3 - Definir a função: exibir_filas
    Med) Exibindo a quantidade de clientes
    Hard) Fazer um desenho da fila
'''

#cria fila vazia
def criar_lista():
    lista = []
    return lista

#insere um cliente na fila
def inserir_cliente(fila):
    prioridade = int(input("Digite 0 se o cliente for prioritário. Se não, digite 1: "))
    if prioridade == 0:
        fila.append(0)
    else:
        fila.append(1)

#insere n clientes na fila        
def inserir_clientes(fila, n):
    contador = 0
    while contador < n:
        inserir_cliente(fila)
        contador += 1
    return(fila)

#atende um cliente normal
def atender_cliente_normal(fila):
    for i in range(len(fila)):
        if fila[i] == 1:
            fila.pop(i)
            return fila
            break
        else:
            continue
        
#atende um cliente prioritário
def atender_cliente_prioritario(fila):
    for i in range(len(fila)):
        if fila[i] == 0:
            fila.pop(i)
            return fila
            break
        else:
            continue

#atende n clientes (nível hard: primeiro os prioritários,
# mas não mais de quatro prioritários seguidos)
def atender_clientes(fila, n):
    contador_pri = 0
    contador = 0
    while contador < n:
        while contador_pri < 4:
            atender_cliente_prioritario(fila)
            contador_pri += 1
            contador += 1
        atender_cliente_normal(fila)
        contador_pri = 0 #reiniciar o contador de prioridade
        contador += 1

#exibir fila bonitinho          
        #p são clientes prioritários
        #n são clientes normais
        #com distanciamento social! :)
def exibir_fila(fila):
    print()
    for i in range(len(fila)):
        print("----", end = "")
    print()
    for i in range(len(fila)):
        if fila[i] == 0:
            print('p', end = "")
            print("   ", end = "")
        elif fila[i] == 1:
            print('n', end = "")
            print("   ", end = "")
        else: 
            print("Essa fila não é válida") #fila só pode ter 0s e 1s
    print()
    for i in range(len(fila)):
        print("----", end = "")
    print()


fila = criar_lista()

#o primeiro argumento é a fila, e o segundo é o número de clientes 
#que você quer inserir
inserir_clientes(fila, 10)

print()
print("Lista antes do antendimento:")
exibir_fila(fila)

#o primeiro argumento é a fila, e o segundo é o número de clientes 
#que você quer atender
atender_clientes(fila, 6)

print()
print("Lista depois do antendimento:")
exibir_fila(fila)

#se lista for por exemplo [0,0,0,0,0,0,1,1,0,1]
#nao funciona
