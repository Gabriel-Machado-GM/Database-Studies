for i, el in enumerate([1,2,3]):
    