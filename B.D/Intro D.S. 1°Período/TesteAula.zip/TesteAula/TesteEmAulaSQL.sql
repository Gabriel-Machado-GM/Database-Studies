#Alunos: 	André Paixão, Gabriel Machado, João Vínicius, Mateus Amaral
#SQL 1
SELECT		store.store_id as "Loja", COUNT(customer.customer_id) as "Quantidade de Clientes", SUM(payment.amount) as "Soma dos valores pagos"
FROM		customer, store, payment
WHERE		customer.store_id = store.store_id and customer.customer_id = payment.payment_id
GROUP BY	store.store_id
ORDER BY	SUM(payment.amount) DESC
LIMIT		1;

#SQL 2
SELECT		CONCAT(customer.first_name, " ", customer.last_name) as "Clientes",  max(rental.rental_date) as "Ultimo aluguel"
FROM		customer, rental
WHERE		customer.customer_id = rental.customer_id
GROUP BY	1;

#SQL 3
SELECT		category.name AS "Categoria", COUNT(rental.rental_id) AS "Nº de locações"
FROM		film, category, film_category, rental, inventory
WHERE 		film.film_id = inventory.film_id
	AND		inventory.inventory_id = rental.inventory_id
	AND 	film.film_id = film_category.film_id
	AND 	film_category.category_id = category.category_id
GROUP BY 	category.category_id
ORDER BY 	2 DESC;

#SQL 4
SELECT		LEFT(payment.payment_date, 7) as "Data", SUM(payment.amount) as "Receita"
FROM		payment
GROUP BY	1;

#SQL BONUS
SELECT  	LEFT(rental.rental_date, 7) as "Mês", COUNT(DISTINCT rental.customer_id) as "Quantidade de clientes unicos"
FROM		rental
GROUP BY	1;


